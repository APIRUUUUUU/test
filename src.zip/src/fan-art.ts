export type FanArtItem = {
  id: string;
  image: string;
  alt: string;
  artist?: string;
  postUrl?: string;
};

export const fanArtItems: FanArtItem[] = [
  {
    id: "criyokan-2080959510160834974",
    image: "https://pbs.twimg.com/media/HOEM72WboAAJHNZ?format=jpg&name=large",
    alt: "ホイップあんさんによる黄白レモのファンアート",
    artist: "@criyokan",
    postUrl: "https://x.com/criyokan/status/2080959510160834974"
  },
  {
    id: "kaijyu-lv27-2078684510162690175",
    image: "https://pbs.twimg.com/media/HNj2yTzaIAAziK5?format=jpg&name=large",
    alt: "貝獣 Lv.27さんによる黄白レモのファンアート",
    artist: "@kaijyu_Lv27",
    postUrl: "https://x.com/kaijyu_Lv27/status/2078684510162690175"
  },
  {
    id: "cwsm6-2069089960909734219",
    image: "https://pbs.twimg.com/media/HLbiWBLbYAAklEE?format=jpg&name=large",
    alt: "川嶋さんによる黄白レモのファンアート",
    artist: "@cwsm6",
    postUrl: "https://x.com/cwsm6/status/2069089960909734219"
  },
  {
    id: "guribato-2051619316018340055",
    image: "https://pbs.twimg.com/media/HHjQ5FEbEAEgb8K?format=jpg&name=large",
    alt: "ぐりばーと。さんによる黄白レモのファンアート",
    artist: "@guribato",
    postUrl: "https://x.com/guribato/status/2051619316018340055"
  },
  {
    id: "rumre-sn-1604049558799286272",
    image: "https://pbs.twimg.com/media/FkK6klOaEAAualD?format=jpg&name=large",
    alt: "rumreさんによる黄白レモのファンアート",
    artist: "@rumre_sn",
    postUrl: "https://x.com/rumre_sn/status/1604049558799286272"
  },
  {
    id: "rixyou007-2031745969281450437",
    image: "https://pbs.twimg.com/media/HDI2J9qbUAAK3EF?format=jpg&name=large",
    alt: "rixyouさんによる黄白レモのファンアート",
    artist: "@rixyou007",
    postUrl: "https://x.com/rixyou007/status/2031745969281450437"
  },
  {
    id: "yuzu35897780502-2066906809269690577",
    image: "https://pbs.twimg.com/media/HK8e-zFbYAAqvnt?format=png&name=large",
    alt: "@yuzu35897780502さんによる黄白レモのファンアート",
    artist: "@yuzu35897780502",
    postUrl: "https://x.com/yuzu35897780502/status/2066906809269690577"
  },
  {
    id: "kaijyu-lv27-2030321407775945120",
    image: "https://pbs.twimg.com/media/HC0kSC0bYAA78Q_?format=jpg&name=large",
    alt: "貝獣 Lv.27さんによる黄白レモのファンアート",
    artist: "@kaijyu_Lv27",
    postUrl: "https://x.com/kaijyu_Lv27/status/2030321407775945120"
  },
  {
    id: "cwsm6-1985632560513499257",
    image: "https://pbs.twimg.com/media/G45iGlIbUAAsHY1?format=png&name=large",
    alt: "川嶋さんによる黄白レモのファンアート",
    artist: "@cwsm6",
    postUrl: "https://x.com/cwsm6/status/1985632560513499257"
  },
  {
    id: "rinkaa1113aecs-1510161660480135173",
    image: "https://pbs.twimg.com/media/FPUrwAyVkAAHyhb?format=jpg&name=large",
    alt: "@rinkaa1113aecsさんによる黄白レモのファンアート",
    artist: "@rinkaa1113aecs",
    postUrl: "https://x.com/rinkaa1113aecs/status/1510161660480135173"
  },
  {
    id: "kamimurahiiro-1639610965548470272",
    image: "https://pbs.twimg.com/media/FsERe19acAAjAUV?format=jpg&name=large",
    alt: "@kamimurahiiroさんによる黄白レモのファンアート",
    artist: "@kamimurahiiro",
    postUrl: "https://x.com/kamimurahiiro/status/1639610965548470272"
  },
  {
    id: "toukouji76-2064729136288133600",
    image: "https://pbs.twimg.com/media/HKdkMv0boAAn7dk?format=jpg&name=large",
    alt: "@toukouji76さんによる黄白レモのファンアート",
    artist: "@toukouji76",
    postUrl: "https://x.com/toukouji76/status/2064729136288133600"
  },
  {
    id: "rixyou007-2031732689251053874",
    image: "https://pbs.twimg.com/media/HDIqGUWaIAAcL3m?format=jpg&name=large",
    alt: "rixyouさんによる黄白レモのファンアート",
    artist: "@rixyou007",
    postUrl: "https://x.com/rixyou007/status/2031732689251053874"
  },
  {
    id: "kaijyu-lv27-2059084285404197329",
    image: "https://pbs.twimg.com/media/HJNVMsva4AARpXV?format=jpg&name=large",
    alt: "貝獣 Lv.27さんによる黄白レモのファンアート",
    artist: "@kaijyu_Lv27",
    postUrl: "https://x.com/kaijyu_Lv27/status/2059084285404197329"
  },
  {
    id: "guribato-1969710735510122927",
    image: "https://pbs.twimg.com/media/G1XReJka4AApOYA?format=jpg&name=large",
    alt: "ぐりばーと。さんによる黄白レモのファンアート",
    artist: "@guribato",
    postUrl: "https://x.com/guribato/status/1969710735510122927"
  },
  {
    id: "satsuma73382672-1774664710316773673",
    image: "https://pbs.twimg.com/media/GKDfyI7bUAAdvFF?format=jpg&name=large",
    alt: "@satsuma73382672さんによる黄白レモのファンアート",
    artist: "@satsuma73382672",
    postUrl: "https://x.com/satsuma73382672/status/1774664710316773673"
  },
  {
    id: "irohanoazzz-1953359465358721330",
    image: "https://pbs.twimg.com/media/Gxu6FEtaQAA1M3v?format=jpg&name=large",
    alt: "@irohaNoazzZさんによる黄白レモのファンアート",
    artist: "@irohaNoazzZ",
    postUrl: "https://x.com/irohaNoazzZ/status/1953359465358721330"
  },
  {
    id: "kamimurahiiro-1639856314796109825",
    image: "https://pbs.twimg.com/media/FsHwn9gaEAcEkOF?format=jpg&name=large",
    alt: "@kamimurahiiroさんによる黄白レモのファンアート",
    artist: "@kamimurahiiro",
    postUrl: "https://x.com/kamimurahiiro/status/1639856314796109825"
  }
];
