export type AssetSlot = {
  label: string;
  src: string;
  alt: string;
  note: string;
};

export const siteConfig = {
  nameJa: "黄白レモ",
  nameEn: "KISHIRO LEMO",
  monogram: "L",
  catchphrase: "フレッシュでエネルギッシュなVTuberアイドル。",
  description:
    "フレッシュでエネルギッシュなVTuberアイドル。明るく元気な配信で、視聴者の皆さんに笑顔と元気をお届けします！",
  hashtag: "#黄白レモ",
  nav: [
    { label: "ABOUT", href: "/#about" },
    { label: "MUSIC", href: "/#music" },
    { label: "WORKS", href: "/#works" },
    { label: "GOODS", href: "/#goods" },
    { label: "GUIDELINE", href: "/guideline/" },
    { label: "CONTACT", href: "/#contact" }
  ],
  seo: {
    home: {
      title: "黄白レモ オフィシャルサイト",
      description: "アイドル見習いVTuber"
    },
    profile: {
      title: "PROFILE | 黄白レモ オフィシャルサイト",
      description:
        "VTuberアイドル・黄白レモのプロフィール、活動情報、ハッシュタグ、衣装ギャラリーを紹介します。"
    },
    guideline: {
      title: "GUIDELINE | 黄白レモ オフィシャルサイト",
      description:
        "黄白レモのファン活動、二次創作、切り抜き動画、SNSでの交流に関するガイドラインです。"
    }
  },
  assets: {
    headerLogo: {
      label: "HEADER LOGO",
      src: "/images/header-logo.webp",
      alt: "Kishiro ロゴ",
      note: "透過WebP推奨 / 横長"
    },
    affiliationLogo: {
      label: "AFFILIATION LOGO",
      src: "/images/vjidai-logo.png",
      alt: "ぶいじだい Vjidai production",
      note: "透過PNG推奨 / 横長"
    },
    logo: {
      label: "LOGO",
      src: "/images/logo.png",
      alt: "黄白レモ ロゴ",
      note: "透過PNG推奨 / 横長"
    },
    keyVisual: {
      label: "KEY VISUAL",
      src: "/images/key-visual.png",
      alt: "黄白レモ キービジュアル",
      note: "1920x1200以上推奨"
    },
    keyVisualBackground: {
      label: "KEY VISUAL BACKGROUND",
      src: "/images/hero-background.jpg",
      alt: "黄白レモ キービジュアル背景",
      note: "人物レイヤーと同じサイズ"
    },
    keyVisualCharacter: {
      label: "KEY VISUAL CHARACTER",
      src: "/images/hero-character.png",
      alt: "空へ手を伸ばす黄白レモ",
      note: "背景レイヤーと同じサイズ / 透過PNG"
    },
    keyVisualFinal: {
      label: "KEY VISUAL FINAL",
      src: "/images/hero-final.jpg",
      alt: "黄白レモ アイドル化プロジェクト キービジュアル",
      note: "演出後に表示する完成画像"
    },
    standing: {
      label: "STANDING",
      src: "/images/standing.png",
      alt: "黄白レモ 立ち絵",
      note: "透過PNG推奨 / 全身"
    },
    shop: {
      label: "GOODS",
      src: "/images/shop-main.png",
      alt: "グッズ画像",
      note: "正方形または4:3"
    }
  } satisfies Record<string, AssetSlot>,
  links: [
    {
      category: "YouTube",
      title: "黄白レモ 公式YouTubeチャンネル",
      meta: "OFFICIAL CHANNEL",
      href: "https://www.youtube.com/@kishirolemo"
    },
    {
      category: "X",
      title: "黄白レモ 公式X",
      meta: "LATEST UPDATES",
      href: "https://x.com/kishiro_lemo"
    },
    {
      category: "Project",
      title: "アイドル化プロジェクト",
      meta: "SPECIAL PAGE",
      href: "https://www.kishiro-lemo.jp/idol-project"
    }
  ],
  profile: [
    { label: "Affiliation", value: "ぶいじだい" },
    { label: "Birthday", value: "11月12日" },
    { label: "Height", value: "157cm" },
    { label: "Favorite food", value: "パイナップル、ポップコーン" },
    { label: "Likes", value: "おしゃべり、企画、演出、歌" }
  ],
  tags: [
    {
      label: "総合",
      value: "#黄白レモ",
      href: "https://x.com/search?q=%23%E9%BB%84%E7%99%BD%E3%83%AC%E3%83%A2&src=hashtag_click"
    },
    {
      label: "企画",
      value: "#黄城高校",
      href: "https://x.com/search?q=%23%E9%BB%84%E5%9F%8E%E9%AB%98%E6%A0%A1&src=hashtag_click"
    },
    {
      label: "ファンアート",
      value: "#黄白絵も",
      href: "https://x.com/search?q=%23%E9%BB%84%E7%99%BD%E7%B5%B5%E3%82%82&src=hashtag_click"
    },
    {
      label: "配信",
      value: "#打ち上げレモ",
      href: "https://x.com/search?q=%23%E6%89%93%E3%81%A1%E4%B8%8A%E3%81%92%E3%83%AC%E3%83%A2&src=hashtag_click"
    }
  ],
  gallery: [
    {
      src: "/images/gallery/01-stage.webp",
      alt: "制服姿でメガホンを持つ黄白レモ"
    },
    {
      src: "/images/gallery/02-modern.png",
      alt: "白いジャケットと黄色いスカートの黄白レモ"
    },
    {
      src: "/images/gallery/03-winter-blue.png",
      alt: "水色のニット衣装を着た黄白レモ"
    },
    {
      src: "/images/gallery/04-winter-yellow.png",
      alt: "白と黄色の冬衣装を着た黄白レモ"
    },
    {
      src: "/images/gallery/05-idol-yellow.png",
      alt: "黄色のアイドル衣装を着た黄白レモ"
    },
    {
      src: "/images/gallery/06-classic.png",
      alt: "モノトーン衣装を着た黄白レモ"
    }
  ],
  movies: [
    {
      title: "無理すぎ♡オタクハート",
      meta: "MUSIC VIDEO",
      image: "https://img.youtube.com/vi/nNfUbr1jfzE/maxresdefault.jpg",
      href: "https://youtu.be/nNfUbr1jfzE?si=lFfqoeADOVKXwh7F"
    },
    {
      title: "ビバハピ",
      meta: "MUSIC VIDEO",
      image: "https://img.youtube.com/vi/QZK-ER4BCug/maxresdefault.jpg",
      href: "https://youtu.be/QZK-ER4BCug?si=RYnPdrLG6i8-hlX-"
    },
    {
      title: "だいしゅきーだいしゅき",
      meta: "MUSIC VIDEO",
      image: "https://img.youtube.com/vi/beSNLQf3kWs/maxresdefault.jpg",
      href: "https://youtu.be/beSNLQf3kWs?si=SdijwqfGNoRH6ufq"
    },
    {
      title: "可愛くなりたい",
      meta: "MUSIC VIDEO",
      image: "https://img.youtube.com/vi/LblgooWk6Zo/maxresdefault.jpg",
      href: "https://youtu.be/LblgooWk6Zo?si=myRXoTyT8p33xcjZ"
    },
    {
      title: "完全放棄宣言",
      meta: "MUSIC VIDEO",
      image: "https://img.youtube.com/vi/KpiYKWqTQVY/maxresdefault.jpg",
      href: "https://youtu.be/KpiYKWqTQVY?si=s5lSaEMSseb8bvWp"
    },
    {
      title: "キミと××××したいだけ",
      meta: "MUSIC VIDEO",
      image: "https://img.youtube.com/vi/70clqqm1IZc/maxresdefault.jpg",
      href: "https://youtu.be/70clqqm1IZc?si=zaWLovRNP8xKAJeg"
    },
    {
      title: "シンデレラ",
      meta: "MUSIC VIDEO",
      image: "https://img.youtube.com/vi/OrxK0ONuyTk/maxresdefault.jpg",
      href: "https://youtu.be/OrxK0ONuyTk?si=3DtjhB0AQo2Et4jg"
    },
    {
      title: "愛言葉Ⅲ",
      meta: "MUSIC VIDEO",
      image: "https://img.youtube.com/vi/yZtJAUMEvWM/maxresdefault.jpg",
      href: "https://youtu.be/yZtJAUMEvWM?si=FKQ3DIzb_YwWVjAE"
    },
    {
      title: "嗚呼、素晴らしいニャン生",
      meta: "MUSIC VIDEO",
      image: "https://img.youtube.com/vi/Y7NyFSjIFQg/maxresdefault.jpg",
      href: "https://youtu.be/Y7NyFSjIFQg?si=YtloRAUZPyhvTWqt"
    },
    {
      title: "みむかゥわナイストライ",
      meta: "MUSIC VIDEO",
      image: "https://img.youtube.com/vi/ILWJ9T9FyRo/maxresdefault.jpg",
      href: "https://youtu.be/ILWJ9T9FyRo?si=2i7oOyZo02QT3CQN"
    }
  ],
  works: [
    {
      year: "2026",
      items: [
        { client: "NEXproduction様", title: "戦国ボイスコミック『鎖訊櫻賭』資良役" }
      ]
    },
    {
      year: "2025",
      items: [
        { client: "NEXproduction様", title: "戦国ボイスコミック『鎖訊櫻賭』女忍役" },
        { client: "", title: "シヴィライゼーションモバイルPR案件" },
        { client: "", title: "Huel PR案件" }
      ]
    },
    {
      year: "2024",
      items: [
        { client: "Attend me様", title: "『推カン』PR配信" },
        { client: "Room8様", title: "アプリ新機能紹介案件配信" },
        { client: "Attend me様", title: "『推しカード』案件" },
        { client: "SAT-BOX様", title: "『定規バトルオンライン』紹介配信" }
      ]
    },
    {
      year: "2023",
      items: [
        { client: "株式会社uyet様", title: "バーチャル物産展おすそわけフェス" },
        { client: "京もつ鍋亀八様", title: "『辛鍋』案件配信" },
        { client: "株式会社uyet様", title: "バーチャル物産展 はしゃげ！海辺のサマーフェス" },
        { client: "Room8様", title: "アプリ紹介案件配信" },
        { client: "ポムの樹様×株式会社uyet様", title: "人類オムライス化計画" },
        { client: "100時間カレー様", title: "レトルト100時間カレー＆飲むスパイスセット案件配信" }
      ]
    },
    {
      year: "2022",
      items: [
        { client: "プロパキャスト様", title: "Vtuberトークイベント Vtu\"Bar\"出演" }
      ]
    }
  ],
  shopItems: [
    {
      label: "ぶいじだい公式BOOTH",
      image: "/images/goods/booth.webp",
      alt: "ぶいじだい公式BOOTHはこちら",
      href: "https://vjidai.booth.pm/items"
    },
    {
      label: "黄白レモ らいどりファンクラブ",
      image: "/images/goods/rideori.webp",
      alt: "黄白レモ らいどりファンクラブ",
      href: "https://raidori.com/@kishiro_lemo"
    }
  ],
  gameUrl: "https://plicy.net/GamePlay/217070",
  contactUrl: "https://docs.google.com/forms/d/e/1FAIpQLScxiYGCd2Cf7CSFrY918omatwU58vNibKa16conK-llAxGA_g/viewform?usp=header",
  guidelineLead: "みんなが楽しく過ごせるように、以下のルールを守ってくださいね！",
  guidelines: [
    {
      title: "呼び方",
      text: "「レモちゃん」「きしろん」など、親しみやすい呼び方でOKです。敬称は自由ですが、過度に馴れ馴れしい呼び方はご遠慮ください。"
    },
    {
      title: "ファンアート・二次創作",
      text: "イラストや小説、実物のアートなど大歓迎です。投稿時は「#黄白絵も」をご利用ください。公序良俗に反する内容や過度な性的表現は禁止です。商用利用は事前にご相談ください。"
    },
    {
      title: "切り抜き動画",
      text: "概要欄に元配信のURLを必ず記載し、Xへの投稿時は「#カットレモ」をご利用ください。誤解を招く誇張や悪意のある編集は禁止です。"
    },
    {
      title: "SNSでの交流",
      text: "リプライには返信できない場合があります。個人情報の詮索や、他のVTuberとの比較・対立を煽る発言はお控えください。"
    }
  ]
};
